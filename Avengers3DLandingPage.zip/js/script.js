
gsap.from("#title", { duration: 2, y: -100, opacity: 0, ease: "bounce" });
gsap.from(".subtitle", { duration: 2, delay: 0.5, opacity: 0, y: 30 });
gsap.from(".movie-card", {
  duration: 1.5,
  opacity: 0,
  y: 50,
  stagger: 0.3,
  delay: 1
});
